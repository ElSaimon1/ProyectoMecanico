#from django.conf.url import url
from django.urls import path
from . import views



urlpatterns = [
    path('formulario', views.formulario, name='formulario'),
    path('home', views.home, name='home'),
    path('login', views.login, name='login'),
    path('perfilMC', views.perfilMC, name='perfilMC'),
    path('register', views.register, name='register'),
    path('servicio', views.servicio, name='servicio'),
    path('', views.base, name='base'),

    path('crud', views.crud, name='crud'),
    path('registroServicioAdd', views.registroServicioAdd, name='registroServicioAdd'),
    path('registroServicio_del/<str:pk>', views.registroServicio_del, name='registroServicio_del'),
    path('registroServicio_edit/<str:pk>', views.registroServicio_edit, name='registroServicio_edit'),
    path('registroServicio_act', views.registroServicio_act, name='registroServicio_act'),
    
    # path('crud_Tiposervicio', views.crud_Tiposervicio, name='crud_Tiposervicio'),
    # path('TiposervicioAdd', views.TiposervicioAdd, name='TiposervicioAdd'),
    # path('Tiposervicio_del/<str:pk>', views., name=''),
    # path('', views., name=''),
    # path('', views., name=''),
    # path('', views., name=''),
    # path('', views., name=''),
    # path('', views., name=''),

]