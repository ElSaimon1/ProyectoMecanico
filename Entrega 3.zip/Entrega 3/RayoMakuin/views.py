from django.shortcuts import render
from .models import Formulario, Tipo_servicio, Comuna
from django.contrib.auth.decorators import login_required

# Create your views here.


def formulario(request):
    context={}
    return render(request, 'RayoMakuin/formulario.html', context)

def home(request):
    context={}
    return render(request, 'RayoMakuin/home.html', context)

def login(request):
    context={}
    return render(request, 'RayoMakuin/login.html', context)

@login_required
def login(request):
    request.session["usuario"] ="saimondo"
    usuario = request.session["usuario"]
    context = {'usuario':usuario}
    return render(request, 'RayoMakuin/login.html', context )

def perfilMC(request):
    context={}
    return render(request, 'RayoMakuin/perfilMC.html', context)

def register(request):
    context={}
    return render(request, 'RayoMakuin/registro.html', context)

def crud(request):
    RayoMakuin = Formulario.objects.all()
    context = {"Formularios":RayoMakuin}    
    return render(request,'RayoMakuin/registroServicio_list.html',context)

def registroServicioAdd(request):
    if  request.method != "POST":
        tipo_servicios = Tipo_servicio.objects.all()
        comunas = Comuna.objects.all()
        context = {"tipo_servicios":tipo_servicios, "Comunas":comunas}
        return render(request, 'RayoMakuin/registroServicio_add.html', context)
    
    else:
        
        patente = request.POST["patente"]
        marca = request.POST["marca"]
        modelo = request.POST["modelo"]
        telefono = request.POST["telefono"]
        tipo_ser = request.POST["tipo_ser"]
        comuna = request.POST["comuna"]
        Detalle_ser = request.POST["detalles_servicio"]

        objTipo_servicio = Tipo_servicio.objects.get(id_tipo_ser = tipo_ser)
        objComuna = Comuna.objects.get(id_comuna = comuna)
        obj=Formulario.objects.create(  patente = patente,
                                        marca = marca,
                                        modelo = modelo,
                                        telefono = telefono,
                                        tipo_ser = objTipo_servicio,
                                        comuna = objComuna,
                                        Detalles_servicio = Detalle_ser)
        obj.save()
        context = {'mensaje' : "OK, Guardando Datos..."}
        return render(request, 'RayoMakuin/registroServicio_add.html', context)
    
def registroServicio_del(request,pk):
    context={}
    try:
        registro = Formulario.objects.get(patente=pk)

        registro.delete()
        mensaje = "Bien, datos eliminados...."
        registros = Formulario.objects.all()
        context = { 'registros': registros, 'mensaje': mensaje}
        return render(request, 'RayoMakuin/registroServicio_list.html', context)
    except:
        mensaje = "Error, patente no existe..."
        registros = Formulario.objects.all()
        context = { 'registros': registros, 'mensaje': mensaje}
        return render(request, 'RayoMakuin/registroServicio_list.html', context)
    
def registroServicio_edit(request,pk):
    if pk != "":
        registro = Formulario.objects.get(patente=pk)
        tipo_servicios = Tipo_servicio.objects.all()
        comunas = Comuna.objects.all()

        print(type(registro.tipo_ser.Servicio))
        print(type(registro.comuna.nom_comuna))

        context = {"tipo_servicios":tipo_servicios, "Comunas":comunas}
        if registro:
            return render(request, 'RayoMakuin/registroServicio_edit.html', context)
        else:
            context={'mensaje':'Error, patente no existe...'}
            return render(request, 'RayoMakuin/registroServicio_list.html', context)
        
from django.shortcuts import get_object_or_404
from django.urls import reverse

def registroServicio_act(request, id=None):
    if request.method == "POST":
        if id:
            registro = get_object_or_404(Formulario, id=id)
        else:
            registro = Formulario()

        registro.patente = request.POST.get("patente")
        registro.marca = request.POST.get("marca")
        registro.modelo = request.POST.get("modelo")
        registro.telefono = request.POST.get("telefono")
        registro.tipo_ser = Tipo_servicio.objects.get(id_tipo_ser=request.POST.get("tipo_ser"))
        registro.comuna = Comuna.objects.get(id_comuna=request.POST.get("comuna"))
        registro.Detalles_servicio = request.POST.get("detalles_servicio")
        registro.save()

        context = {
            "mensaje": "OK, datos actualizados...",
            "tipo_servicios": Tipo_servicio.objects.all(),
            "Comunas": Comuna.objects.all(),
            "registro": registro,
            "Formulario": True,
        }
        return render(request, 'RayoMakuin/registroServicio_edit.html', context)
    else:
        registro = Formulario.objects.all()
        context = {
            'registros': registro
        }
        return render(request, 'RayoMakuin/registroServicio_list.html', context)


def servicio(request):
    context={}
    return render(request, 'RayoMakuin/servicio.html', context)

def base(request):
    context={}
    return render(request, 'RayoMakuin/base.html', context)

