from django import forms
from .models import Tipo_servicio, Comuna

from django.forms import ModelForm

class Tipo_servicioForm(ModelForm):
    class meta:
        model = Tipo_servicio
        field = "__all__"

class ComunaForm(ModelForm):
    class meta:
        model = Comuna
        field = "__all__"